from setuptools import setup

setup(
    name='hashget-kernel_org',
    version='0.3',
    description='',
    long_description='',
    author='Yaroslav Polyakov',
    author_email='yaroslaff@gmail.com',

    license='Apache Software License',

    packages=['hashget.heuristics.kernel_org'],
    zip_safe=False,
)

